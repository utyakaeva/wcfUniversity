﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using Word = Microsoft.Office.Interop.Word;
using Microsoft.Office.Interop.Word;
using System.IO;
using System.Data.SqlClient;

namespace WcfSERVER
{
    [DataContract]
    public class Order
    {
        [DataMember]
        public int ID;
        [DataMember]
        public Client client;
        [DataMember]
        public Worker worker;
        [DataMember]
        public List<Service> services;
        [DataMember]
        public string Comment;
        [DataMember]
        public string StartDate;
        [DataMember]
        public string DateLastUpdate;
        [DataMember]
        public string EndDate;
        [DataMember]
        public double Cost;
        [DataMember]
        public string Status;
        [DataMember]
        public bool Deleted;

        public Order()
        {
        }

        public Order(int id, Client cl, Worker emp, List<Service> services, string comment, string StartDate, string DateLastUpdate, string enddate, double cost,string status, bool del)
        {
            this.ID = id;
            this.services = services;
            this.client = cl;
            this.worker = emp;
            this.Comment = comment;
            this.StartDate = StartDate;
            this.DateLastUpdate = DateLastUpdate;
            this.EndDate = enddate;
            this.Status = status;
            this.Cost = cost;
            this.Deleted = del;
        }
    }
    class Orders
    {
        static public void Add(Order order)
        {
            string sql = System.String.Format("INSERT INTO Orders SET CLIENT_ID={0},WORKER_ID={1}, COMMENT=@comment,COST=@cost,DATE='{2}',DATELASTUP = '{3}',END_DATE='{4}',STATUS = '{5}'", order.client.ID, order.worker.ID, order.StartDate, order.DateLastUpdate, order.EndDate,order.Cost,order.Status); // Строка запроса
            SqlCommand comm = baseDB.PrepareRequest(sql);
            comm.Parameters.AddWithValue("@cost", order.Cost);
            comm.Parameters.AddWithValue("@comment", order.Comment);
            System.Data.DataTable dt = baseDB.ExecutePrepared();
           int orderID = baseDB.LastInsertedID();
            foreach (Service serv in order.services)
            {
                sql = System.String.Format("INSERT INTO Services_in_Orders SET ORDER_ID={0} ,SERVICE_ID={1}", orderID, serv.ID); // Строка запроса
                dt = baseDB.SendRequest(sql);
            }
        }
        public static void Update(Order order)
        {


            string sql = System.String.Format("UPDATE  Orders SET CLIENT_ID={0},WORKER_ID={1}, COMMENT=@comment,COST=@cost,DATE='{2}',DATELASTUP = '{3}',END_DATE='{4}',STATUS = '{5}'", order.client.ID, order.worker.ID, order.StartDate, order.DateLastUpdate, order.EndDate, order.Cost, order.Status); // Строка запроса
            SqlCommand comm = baseDB.PrepareRequest(sql);
            comm.Parameters.AddWithValue("@cost", order.Cost);
            comm.Parameters.AddWithValue("@comment", order.Comment);
            System.Data.DataTable dt = baseDB.ExecutePrepared();
            sql = System.String.Format("DELETE FROM Services_in_Orders WHERE ORDER_ID={0}", order.ID); // Строка запроса
            dt = baseDB.SendRequest(sql);
            foreach (Service serv in order.services)
            {
                sql = System.String.Format("INSERT INTO Services_in_Orders SET ORDER_ID={0} ,SERVICE_ID={1}", order.ID, serv.ID); // Строка запроса
                dt = baseDB.SendRequest(sql);
            }
        }
        public static void Delete(int ID)
        {

            string sql = System.String.Format("UPDATE Orders SET DEL='true' WHERE ID={0}", ID); // Строка запроса
            System.Data.DataTable dt = baseDB.SendRequest(sql);
        }
        public static List<Order> GetOrders(int page, int count, string order_by)//type: 0 - все, 1 - неудалённых, 2 - удалённых
        {
            List<Order> list = new List<Order>();
            int startID = count * (page - 1);
            string OB = "";
            switch (order_by)
            {
                case "0":
                    OB = "Orders.ID";
                    break;
                case "1":
                    OB = "LAST_NAME";
                    break;
                case "2":
                    OB = "DATE DESC";
                    break;
            }
            string sql = String.Format("SELECT * FROM Orders inner join Clients on Orders.CLIENT_ID = Clients.ID  WHERE Orders.DEl <> 'true' ORDER BY {0} LIMIT {1},{2}", OB, startID, count); // Строка запроса
            System.Data.DataTable dt = baseDB.SendRequest(sql);
            var myData = dt.Select();
            for (int i = 0; i < myData.Length; i++)
            {
                Order order = new Order(Convert.ToInt32(myData[i].ItemArray[0]), Clients.GetClientByID(Convert.ToInt32(myData[i].ItemArray[1])), Workers.GetWorkerByID(Convert.ToInt32(myData[i].ItemArray[2])), Services.GetServicesForOrder(Convert.ToInt32(myData[i].ItemArray[0])), myData[i].ItemArray[4].ToString(), myData[i].ItemArray[6].ToString(), myData[i].ItemArray[7].ToString(), myData[i].ItemArray[8].ToString(), Convert.ToDouble(myData[i].ItemArray[3]), myData[i].ItemArray[9].ToString(), Convert.ToBoolean(myData[i].ItemArray[5]));// Convert.ToInt32(myData[i].ItemArray[0]), myData[i].ItemArray[3].ToString() + " " + myData[i].ItemArray[1].ToString() + " " + myData[i].ItemArray[2].ToString(), myData[i].ItemArray[4].ToString(), myData[i].ItemArray[5].ToString(), myData[i].ItemArray[6].ToString(), myData[i].ItemArray[7].ToString());
                list.Add(order);
            }
            return list;
        }
        public static List<Order> GetOrdersByClient(int page, int count, string order_by, string Client)//type: 0 - все, 1 - неудалённых, 2 - удалённых
        {
            List<Order> list = new List<Order>();
            int startID = count * (page - 1);
            string OB = "";
            switch (order_by)
            {
                case "0":
                    OB = "Orders.ID";
                    break;
                case "1":
                    OB = "LAST_NAME";
                    break;
                case "2":
                    OB = "DATE DESC";
                    break;
            }
            string sql = String.Format("SELECT * FROM Orders inner join Clients on Orders.CLIENT_ID = Clients.ID  WHERE Orders.DEl <> 'true' ORDER BY {0}  LIMIT {1},{2}", OB, startID, count); // Строка запроса
            System.Data.DataTable dt = baseDB.SendRequest(sql);
            var myData = dt.Select();
            for (int i = 0; i < myData.Length; i++)
            {
                Order order = new Order(Convert.ToInt32(myData[i].ItemArray[0]), Clients.GetClientByID(Convert.ToInt32(myData[i].ItemArray[1])), Workers.GetWorkerByID(Convert.ToInt32(myData[i].ItemArray[2])), Services.GetServicesForOrder(Convert.ToInt32(myData[i].ItemArray[0])), myData[i].ItemArray[4].ToString(), myData[i].ItemArray[6].ToString(), myData[i].ItemArray[7].ToString(), myData[i].ItemArray[8].ToString(), Convert.ToDouble(myData[i].ItemArray[3]), myData[i].ItemArray[9].ToString(), Convert.ToBoolean(myData[i].ItemArray[5]));// Convert.ToInt32(myData[i].ItemArray[0]), myData[i].ItemArray[3].ToString() + " " + myData[i].ItemArray[1].ToString() + " " + myData[i].ItemArray[2].ToString(), myData[i].ItemArray[4].ToString(), myData[i].ItemArray[5].ToString(), myData[i].ItemArray[6].ToString(), myData[i].ItemArray[7].ToString());
                Client = Client.ToLower().Trim();
                string clFIO = order.client.FIO;
                clFIO = clFIO.ToLower().Trim();
                if (clFIO.Contains(Client) || order.client.mail.Contains(Client))
                {
                    list.Add(order);
                }
            }
            return list;
        }
        public static Order GetOrderByID(int ID)
        {

            string sql = "SELECT * FROM Orders where ID=" + ID.ToString(); // Строка запроса
            System.Data.DataTable dt = baseDB.SendRequest(sql);
            var myData = dt.Select();
            Order order = new Order(Convert.ToInt32(myData[0].ItemArray[0]), Clients.GetClientByID(Convert.ToInt32(myData[0].ItemArray[1])), Workers.GetWorkerByID(Convert.ToInt32(myData[0].ItemArray[2])), Services.GetServicesForOrder(Convert.ToInt32(myData[0].ItemArray[0])), myData[0].ItemArray[4].ToString(), myData[0].ItemArray[6].ToString(), myData[0].ItemArray[7].ToString(), myData[0].ItemArray[8].ToString(), Convert.ToDouble(myData[0].ItemArray[3]), myData[0].ItemArray[9].ToString(), Convert.ToBoolean(myData[0].ItemArray[5]));
            return order;
        }
        public static int Count()
        {
            string sql = "SELECT * FROM Orders"; // Строка запроса
            System.Data.DataTable dt = baseDB.SendRequest(sql);
            var myData = dt.Select();
            return myData.Count();
        }
        public static byte[] PrintOrder(int ID, int type)
        {
            Order order = Orders.GetOrderByID(ID);
            byte[] array = null;
            if (type == 2)
            {
                Word._Application oWord = new Word.Application();
                string path = Environment.CurrentDirectory + "\\sample.docx";
                _Document oDoc = oWord.Documents.Add(path);
                oDoc.Bookmarks["order_id"].Range.Text = order.ID.ToString();
               
                oDoc.Bookmarks["client_fio"].Range.Text = order.client.FIO;
                oDoc.Bookmarks["client_mail"].Range.Text = order.client.mail;
                oDoc.Bookmarks["comment"].Range.Text = order.Comment;
                oDoc.Bookmarks["date"].Range.Text = order.StartDate;
                oDoc.Bookmarks["worker"].Range.Text = order.worker.FIO;
                Word.Table _table = oDoc.Tables[1];
                int i = 2;
                int j = 1;
                foreach (Service serv in order.services)
                {
                    /*_table.Rows.Add();
                    _table.Cell(i, j).Range.Text = i.ToString();
                    j++;
                    _table.Cell(i, j).Range.Text = serv.name;
                    j++;
                    _table.Cell(i, j).Range.Text = serv.cost + " руб.";
                    j = 1;
                    i++;*/
                }
                _table.Rows.Add();
                _table.Rows[i].Cells[3].Range.Text = order.Cost.ToString() + " руб.";
                _table.Rows[i].Cells[1].Merge(_table.Rows[i].Cells[2]);
                _table.Rows[i].Cells[1].Range.Text = "ИТОГО:";
                oDoc.SaveAs(FileName: Environment.CurrentDirectory + "\\Documents\\Order_" + order.ID + "_2.docx");
                oDoc.Close();
                //Process.Start(Environment.CurrentDirectory + "\\For_print.docx");
                FileStream stream = File.OpenRead(Environment.CurrentDirectory + "\\Documents\\Order_" + order.ID + "_2.docx");
                array = new byte[stream.Length];
                stream.Read(array, 0, array.Length);
                stream.Close();
            }
            return array;
        }
    }
}
