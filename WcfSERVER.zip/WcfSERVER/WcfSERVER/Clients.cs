﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
namespace WcfSERVER
{
    public class Clients
    {
        static public void Add(Client client)
        {
            string[] fio = client.FIO.Split(' ');
 
            string sql = System.String.Format(@"INSERT INTO Clients SET FIRST_NAME='{0}' ,MID_NAME='{1}',LAST_NAME='{2}',MAIL='{3}'", fio[1], fio[2], fio[0], client.mail,client.address,client.dateRegistration,client.password, client.ID); // Строка запроса
            DataTable dt = baseDB.SendRequest(sql);
        }
       
                              

        public static void Update(Client client)
        {
            string[] fio = client.FIO.Split(' ');
            string sql = System.String.Format("UPDATE Clients SET FIRST_NAME='{0}',MID_NAME='{1}',LAST_NAME='{2}',MAIL='{3}',ADDRESS = '{4}',DATEREG='{5}',PASSW ='{6}', WHERE ID={7}", fio[1], fio[2], fio[0], client.mail,client.address,client.dateRegistration,client.password, client.ID); // Строка запроса
            DataTable dt = baseDB.SendRequest(sql);
        }
        public static void Delete(int ID)
        {
            string sql = System.String.Format("UPDATE Clients SET DEL='true' WHERE ID={0}", ID); // Строка запроса
            DataTable dt = baseDB.SendRequest(sql);
        }
        public static List<Client> GetClients(int page, int count, string order_by, int type)
        {
            List<Client> list = new List<Client>();

            int startID = count * (page - 1);
            string sql = "SELECT * FROM Clients WHERE DEl <> 'true' LIMIT " + startID.ToString() + "," + count.ToString(); // Строка запроса
            DataTable dt = baseDB.SendRequest(sql);
            var myData = dt.Select();
            for (int i = 0; i < myData.Length; i++)
            {
                Client cl = new Client(Convert.ToInt32(myData[i].ItemArray[0]), myData[i].ItemArray[1].ToString() + " " + myData[i].ItemArray[2].ToString(), myData[i].ItemArray[3].ToString(), myData[i].ItemArray[4].ToString(), myData[i].ItemArray[5].ToString(), myData[i].ItemArray[6].ToString(), Convert.ToBoolean(myData[i].ItemArray[7]));
                list.Add(cl);
            }
            return list;
        }
        public static List<Client> GetClientsByFIO(string FIO)
        {
            List<Client> list = new List<Client>();
            string sql = "SELECT * FROM Clients"; // Строка запроса
            DataTable dt = baseDB.SendRequest(sql);

            var myData = dt.Select();
            for (int i = 0; i < myData.Length; i++)
            {
                FIO = FIO.ToLower().Trim();
                string clFIO = myData[i].ItemArray[0].ToString() + " " + myData[i].ItemArray[1].ToString() + " " + myData[i].ItemArray[2].ToString();
                clFIO = clFIO.ToLower().Trim();
                if (clFIO.Contains(FIO))
                {
                    Client cl = new Client(Convert.ToInt32(myData[i].ItemArray[0]), myData[i].ItemArray[1].ToString() + " " + myData[i].ItemArray[2].ToString(), myData[i].ItemArray[3].ToString(), myData[i].ItemArray[4].ToString(), myData[i].ItemArray[5].ToString(), myData[i].ItemArray[6].ToString(), Convert.ToBoolean(myData[i].ItemArray[7]));
                    list.Add(cl);
                }
            }
            return list;
        }
        public static Client GetClientByID(int ID)
        {
            string sql = "SELECT * FROM Clients where ID=" + ID.ToString(); // Строка запроса
            DataTable dt = baseDB.SendRequest(sql);
            var myData = dt.Select();
            Client cl = new Client(Convert.ToInt32(myData[0].ItemArray[0]), myData[0].ItemArray[1].ToString() + " " + myData[0].ItemArray[2].ToString(), myData[0].ItemArray[3].ToString(), myData[0].ItemArray[4].ToString(), myData[0].ItemArray[5].ToString(), myData[0].ItemArray[6].ToString(), Convert.ToBoolean(myData[0].ItemArray[7]));
            return cl;
        }
        public static int Count()
        {
            string sql = "SELECT * FROM Clients WHERE DEl <> 'true'"; // Строка запроса
            DataTable dt = baseDB.SendRequest(sql);
            var myData = dt.Select();
            return myData.Count();

        }

    }
}