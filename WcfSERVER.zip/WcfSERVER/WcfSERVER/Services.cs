﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace WcfSERVER
{
    [DataContract]
    public class Service
    {

        [DataMember]
        public int ID;
        [DataMember]
        static public string name;
        [DataMember]
        static public double cost;
        [DataMember]
        public bool del;

        public Service(int v1, string v2, double v3, bool v4)
        {
        }


        /*public Service(int id, string name, double cost, bool del)
       {
           this.ID = id;
           this.name = name;
           this.cost = cost;
           this.del = del;
       }*/
    }
    
    public class Services
    {
        static public void Add(Service service)
        {
            string sqlExpression =(@"INSERT INTO Services (Name, Cost)" + "VALUES (@name, @cost)");
           
                DataTable dtt = baseDB.SendRequest(sqlExpression);

            
               // string sql = System.String.Format(@"INSERT INTO Services (name,cost)"+ "VALUES (@name,@cost)", baseDB.connection); // Строка запроса
           // DataTable dt = baseDB.SendRequest(sql);
            /*  SqlCommand comm = new SqlCommand(@"INSERT INTO Services (name,cost)"+ 
                  "VALUES (@name,@cost)",baseDB.connection);
              SqlCommand commm = baseDB.PrepareRequest(comm);
              commm.Parameters.AddWithValue("@cost", service.cost);
              commm.Parameters.AddWithValue("@name", service.name);
              DataTable dt = baseDB.ExecutePrepared();*/
        }
        public static void Update(Service service)
        {

          /*  string sql = System.String.Format("UPDATE Services SET NAME=@name,COST=@cost WHERE ID={0}", service.ID); // Строка запроса
            SqlCommand comm = baseDB.PrepareRequest(sql);
            comm.Parameters.AddWithValue("@cost", service.cost);
            comm.Parameters.AddWithValue("@name", service.name);
            DataTable dt = baseDB.ExecutePrepared();*/
        }
        public static void Delete(int ID)
        {

            string sql = System.String.Format("UPDATE Services SET DEL='true' WHERE ID={0}", ID); // Строка запроса
            DataTable dt = baseDB.SendRequest(sql);
        }
        public static void Restore(int ID)
        {

            string sql = System.String.Format("UPDATE Services SET DEL='false' WHERE ID={0}", ID); // Строка запроса
            DataTable dt = baseDB.SendRequest(sql);
        }

        public static List<Service> GetServices()
        {

            List<Service> list = new List<Service>();
            string sql = "SELECT * from Services"; // Строка запроса
            DataTable dt = baseDB.SendRequest(sql);
            var myData = dt.Select();
            for (int i = 0; i < myData.Length; i++)
            {
               // Service serv = new Service(Convert.ToInt32(myData[i].ItemArray[0]), myData[i].ItemArray[1].ToString(), Convert.ToDouble(myData[i].ItemArray[2]), Convert.ToBoolean(myData[i].ItemArray[3]));
             //   list.Add(serv);
            }
            return list;
        }
        public static List<Service> GetServicesForOrder(int ID)
        {
            List<Service> list = new List<Service>();
            string sql = "Select * from Services_in_Orders where  ORDER_ID=" + ID; ; // Строка запроса
            DataTable dt = baseDB.SendRequest(sql);
            var myData = dt.Select();
            for (int i = 0; i < myData.Length; i++)
            {
                Service serv = Services.GetServiceByID(Convert.ToInt32(myData[i].ItemArray[2]));
                list.Add(serv);
            }
            return list;
        }
        public static Service GetServiceByID(int ID)
        {
            string sql = "SELECT * FROM Services where ID=" + ID.ToString(); // Строка запроса
            DataTable dt = baseDB.SendRequest(sql);
            var myData = dt.Select();
            Service serv = new Service(Convert.ToInt32(myData[0].ItemArray[0]), myData[0].ItemArray[1].ToString(), Convert.ToDouble(myData[0].ItemArray[2]), Convert.ToBoolean(myData[0].ItemArray[3]));
            return serv;
        }
        public static int Count()
        {
            string sql = "SELECT * FROM Services"; // Строка запроса
            DataTable dt = baseDB.SendRequest(sql);
            var myData = dt.Select();
            return myData.Count();
        }
    }

}
