﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace WcfSERVER
{
    [ServiceContract]
    public interface IClients
    {
        [OperationContract]
        void AddClient(Client client);
        [OperationContract]
        void UpdateClient(Client client);
        [OperationContract]
        void DeleteClient(int id);
        [OperationContract]
        List<Client> GetClients(int page, int count, string order_by, int type);
        [OperationContract]
        List<Client> GetClientsByFIO(string FIO);
        [OperationContract]
        Client GetClientByID(int ID);
        /*[OperationContract]
        Client CreateClient(int ID, string FIO, string phone, bool del);*/
        [OperationContract]
        int CountClients();
    }
}

