﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using WcfSERVER;

namespace WcfSERVER
{
    [ServiceContract]
    public interface IOrders
    {
        [OperationContract]
        void AddOrder(Order order);
        [OperationContract]
        void UpdateOrder(Order order);
        [OperationContract]
        void DeleteOrder(int id);
        [OperationContract]
        List<Order> GetOrders(int page, int count, string order_by);
        [OperationContract]
        List<Order> GetOrdersByClient(int page, int count, string order_by, string client);
        [OperationContract]
        Order GetOrderByID(int ID);
        /* [OperationContract]
         Order CreateOrder(int id, Client cl, Employee emp,List<Service> services, string comment, string Date,double cost, bool del);*/
        [OperationContract]
        int CountOrders();
        [OperationContract]
        byte[] PrintOrder(int ID, int type);
        [OperationContract]
        double CalcOrderCost(Order order);
    }
}
